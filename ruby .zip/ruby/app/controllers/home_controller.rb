class HomeController < ApplicationController
  def Index
  end
end
